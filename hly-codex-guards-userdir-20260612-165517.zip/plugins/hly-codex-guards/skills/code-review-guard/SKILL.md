---
name: code-review-guard
description: Review only the current diff. Focus on real bugs, compatibility risks, transaction issues, state flow errors, SQL correctness, SQL readability and complexity risks, SQL performance risks, and business correctness. Never modify code. Use when the user asks for review, code review, current diff review, SQL review, or explicitly invokes $code-review-guard.
---

# Code Review Guard

## Goal

只进行代码 Review。

禁止修改代码。

禁止生成代码。

禁止自动修复。

Review 结论必须聚焦真实风险，不输出纯风格建议。

## Review Scope

仅检查本次 Diff。

可以读取必要的上下文、调用链、SQL、配置和方法逻辑来验证 Diff 风险，但不要扩展到无关代码、历史遗留问题或未来重构方向。

不要分析：

- 无关代码
- 历史遗留问题
- 未来可能重构的内容
- 与本次 Diff 无关的架构优化

## Evidence Rule

所有结论必须提供证据。

证据必须来自：

- Diff
- 调用链
- SQL
- 配置
- 方法逻辑

不能猜测。

如果无法确认，标记为：不确定。

## Must Check

重点检查：

- 真实 Bug
- 空指针风险
- 事务一致性
- 状态流转错误
- 幂等问题
- 并发问题
- SQL 性能问题
- 索引失效风险
- 大数据量风险
- 历史数据兼容问题
- 枚举兼容问题
- API 兼容问题
- 数据库变更风险
- 多租户隔离问题
- 权限问题
- 金额计算问题
- 结算逻辑问题
- 报表口径问题

## SQL Review Guard

当本次 Diff 涉及 SQL、MyBatis XML、报表 SQL、视图 SQL 或查询逻辑时，除正确性和性能外，还必须检查 SQL 的可读性、可维护性和不必要复杂度。

SQL Review 优先级：

1. 业务口径是否正确
2. 数据范围是否正确
3. JOIN / 聚合 / 去重是否改变数据粒度
4. SQL 是否容易被普通开发人员理解和维护
5. 是否存在不必要的复杂写法
6. 是否存在明确性能风险

不要只因为 SQL 能跑通就认为没有问题。

### SQL 必查项

必须检查：

- 是否存在不必要的 CTE。
- 是否存在多层 CTE 串联导致阅读困难。
- 是否存在无业务含义的 CTE 名称。
- 是否存在不必要的子查询或派生表。
- 是否存在用 `DISTINCT` 掩盖 JOIN 数据膨胀的问题。
- 是否存在无必要的窗口函数。
- 是否存在重复过滤条件或重复业务判断。
- 是否存在复杂 `CASE WHEN` 堆叠。
- 是否存在无明确业务原因的 `COALESCE` / `IFNULL` / `NVL` / `CAST` / `CONVERT`。
- 是否存在字段来源不清晰的问题。
- 是否存在聚合粒度不清晰的问题。
- 是否存在分页顺序不稳定的问题。
- 是否存在 JOIN 后行数膨胀风险。
- 是否存在把 Java 层更适合处理的逻辑强行塞进 SQL 的问题。

### CTE

CTE 不是默认加分项。只有表达明确业务步骤、消除重复逻辑或显著提升可读性时才合理。

以下情况必须标记为风险：

- CTE 名称为 `t1`、`t2`、`tmp`、`temp`、`base`、`data`、`result`、`cte1`、`cte2`。
- CTE 只是把原 SQL 包了一层。
- CTE 只被使用一次，且没有明显提升可读性。
- 多个 CTE 之间字段反复改名、反复加工。
- 一个 CTE 同时做过滤、JOIN、聚合、CASE 转换、去重、分页。
- CTE 层级超过 3 层。
- 最终 SELECT 仍然存在复杂业务计算，说明前面的 CTE 没有真正降低理解成本。

结论中说明：

- CTE 是否必要。
- CTE 是否提升可读性。
- 是否建议改回普通 JOIN / GROUP BY。
- 是否建议拆到 Java 层处理。

### DISTINCT

看到 `DISTINCT` 时，必须追问重复数据来源。

必须检查：

- 重复数据是否真实存在。
- 重复是业务允许的，还是 JOIN 造成的。
- 是否应该修正 JOIN 条件。
- 是否应该先聚合 1:N 明细表再回连主表。
- `DISTINCT` 是否改变原有数据口径。

以下情况必须标记为风险：

- 没有说明原因直接添加 `DISTINCT`。
- 用 `DISTINCT` 修复重复行，但没有定位重复来源。
- `DISTINCT` 后导致金额、数量、人员、订单等明细被错误合并。
- `DISTINCT` 与分页同时使用，但排序字段不稳定。

### JOIN

JOIN 是 SQL Review 的重点。

必须检查：

- 主表是什么。
- 查询结果的目标粒度是什么。
- 每个 JOIN 是否会改变主表行数。
- JOIN 条件是否完整。
- 是否缺少 `tenant_id`。
- 是否缺少业务主键。
- 是否缺少 `is_deleted` / 有效状态过滤。
- 是否存在 1:N 表直接 JOIN 导致主表膨胀。
- LEFT JOIN 条件是否被 WHERE 条件误改成 INNER JOIN 语义。

以下情况必须标记为风险：

- 1:N 明细表直接 JOIN 后又 GROUP BY 主表字段。
- JOIN 条件只按 `id`，但业务上还需要 `tenant_id`。
- LEFT JOIN 后在 WHERE 中过滤右表字段。
- 为解决 JOIN 膨胀使用 `DISTINCT`。
- 聚合前后数据粒度没有说明。

结论中说明：

- JOIN 是否改变数据行数。
- 是否存在数据膨胀风险。
- 是否影响金额、数量、订单数、人员数等统计结果。
- 是否需要先聚合再 JOIN。

### GROUP BY And Aggregation

看到 `GROUP BY` 时，必须检查聚合粒度。

必须确认：

- GROUP BY 的业务粒度是什么。
- SELECT 中每个非聚合字段是否属于该粒度。
- SUM / COUNT / MAX / MIN 是否符合业务口径。
- JOIN 后再聚合是否会导致金额重复计算。
- COUNT(*)、COUNT(1)、COUNT(DISTINCT ...) 是否使用正确。

以下情况必须标记为风险：

- GROUP BY 字段无法表达清晰业务粒度。
- SELECT 字段和 GROUP BY 粒度不一致。
- JOIN 1:N 明细后直接 SUM 主表金额。
- 使用 MAX / MIN 随机取字段但没有业务依据。
- COUNT(DISTINCT ...) 用来掩盖数据膨胀。

### CASE WHEN

复杂 `CASE WHEN` 必须检查业务归属。

必须确认：

- 每个分支是否有明确业务原因。
- 分支顺序是否影响结果。
- 是否存在重叠条件。
- 是否存在遗漏的兜底场景。
- 是否适合改为枚举映射、配置表或 Java 层处理。

以下情况必须标记为风险：

- CASE WHEN 分支超过 3 个但没有说明业务含义。
- CASE WHEN 中嵌套 CASE WHEN。
- 多处重复相同 CASE WHEN。
- 用 CASE WHEN 实现大量状态映射。
- 金额计算中混入复杂 CASE WHEN，且没有说明口径。

### Subquery

子查询不是禁止项，但必须有明确价值。

必须检查：

- 子查询是否真的降低复杂度。
- 是否可以改成普通 JOIN。
- 是否只是为了包一层过滤。
- 是否导致索引无法有效使用。
- 是否存在相关子查询导致逐行执行风险。

以下情况必须标记为风险：

- 多层嵌套子查询。
- 子查询只被使用一次且没有提升可读性。
- SELECT 中出现复杂相关子查询。
- WHERE 中对子查询结果做大量 IN / NOT IN。
- 子查询中排序但外层不依赖排序结果。

### Defensive Functions

不要默认接受无意义的防御性函数。

看到以下函数时必须检查业务原因：

- `COALESCE`
- `IFNULL`
- `NVL`
- `CAST`
- `CONVERT`
- `DATE_FORMAT`
- `STR_TO_DATE`
- `LOWER`
- `UPPER`

以下情况必须标记为风险：

- 没有业务原因的默认值兜底。
- 对索引字段做函数处理导致索引失效。
- 将 NULL 强行转为 0、空字符串或默认状态。
- 类型转换掩盖字段类型设计问题。
- 日期字段格式化后再比较。

结论中说明：

- 函数是否必要。
- NULL / 类型转换的业务含义。
- 是否影响索引使用。
- 是否改变原有结果。

### SQL Simplification

如果 SQL 过度复杂，优先给出最小简化建议。

简化建议必须遵守：

- 不改变业务结果。
- 不改变数据范围。
- 不改变 JOIN 语义。
- 不改变聚合粒度。
- 不改变分页顺序。
- 不引入新表结构。
- 不引入无关重构。

可以建议：

- 删除无意义 CTE。
- 将单次使用的 CTE 改回普通 JOIN。
- 合并重复过滤条件。
- 拆出 1:N 聚合子查询。
- 移除无意义 `DISTINCT`。
- 移除无意义防御性函数。
- 将复杂枚举映射移到 Java 层。
- 将重复 CASE WHEN 抽到统一转换逻辑。

禁止建议：

- 为了“更优雅”重写整条 SQL。
- 无证据地改变表结构或索引。
- 无证据地改变业务口径。
- 无证据地改变分页方式。
- 无证据地添加兼容未来的逻辑。

### SQL Review Conclusion Requirements

SQL Review 结论必须明确回答：

1. 当前 SQL 是否能在 30 秒内理解主业务逻辑。
2. 当前 SQL 是否存在不必要的复杂结构。
3. 当前 SQL 的主表和数据粒度是否清楚。
4. 当前 SQL 是否存在 JOIN 膨胀风险。
5. 当前 SQL 是否存在 `DISTINCT` / `GROUP BY` 掩盖问题。
6. 当前 SQL 是否存在可以安全删除的复杂结构。
7. 当前 SQL 是否需要保持现状，因为复杂性来自真实业务需求。

如果无法确认，必须标记为“不确定”，不能猜测。

## Ignore

不要输出：

- 代码风格建议
- 命名建议
- 重构建议
- 架构优化建议
- “可以更优雅”
- “建议抽方法”
- “建议封装”
- “建议使用设计模式”
- “建议优化 SQL”这类泛泛建议
- 未说明业务风险的纯 SQL 风格问题

## Severity

### P0

- 资损
- 数据错乱
- 权限绕过
- 核心流程不可用

### P1

- 部分功能异常
- 状态错误
- 历史兼容问题
- 明显性能问题
- SQL 复杂写法可能改变业务结果
- JOIN 膨胀可能导致金额、数量、订单数错误
- `DISTINCT` 掩盖数据重复来源
- GROUP BY 粒度错误
- LEFT JOIN 被 WHERE 条件误改为 INNER JOIN
- 分页顺序不稳定导致漏数或重复数据

### P2

- 边界场景问题
- 低概率异常
- SQL 可读性明显较差
- CTE 层级过多或命名无业务含义
- 子查询可以明显简化
- CASE WHEN 复杂且缺少业务说明
- 重复逻辑较多，后续维护容易出错
- 防御性函数没有明确业务原因

### P3

仅用于 SQL 可读性和复杂度补充项：

- SQL 可以更简洁，但当前风险较低。
- 命名不够清楚但不影响理解主流程。
- 存在轻微重复逻辑。
- 存在局部可读性问题。

不要为了输出 P3 而扩大 Review 范围。

## Output Format

使用中文输出，发现项按严重级别排序。

## 风险点清单

### RISK-001

- 严重级别：
- 文件/方法：
- 问题类型：
- 问题描述：
- 触发条件：
- 影响范围：
- 证据：
- 最小修复建议：
- 是否需要补测试：
- 不确定点：

### SQL-READABILITY-001

仅当发现 SQL 可读性或复杂度问题时使用。

- 严重级别：P1/P2/P3
- 文件/方法：
- SQL 位置：
- 问题类型：CTE / DISTINCT / JOIN / GROUP BY / CASE WHEN / 子查询 / 防御性函数 / 其他
- 问题描述：
- 当前 SQL 的业务目标：
- 当前 SQL 的目标数据粒度：
- 风险说明：
- 是否影响结果：是/否/不确定
- 是否影响性能：是/否/不确定
- 是否影响可维护性：是/否
- 证据：
- 最小简化建议：
- 是否需要补测试：
- 不确定点：

## No Risk

如果没有发现风险：

## 风险点清单

未发现明确 P0/P1/P2/P3 风险。

## 不确定点

列出需要人工确认的内容。
